/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author youssef
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

//Admin Class ----------------------------------------------------------------------------------------------------------------------------------
public class gui {
    private String userName;
    private String password;

    public gui(String userName, String password){
        this.userName = userName;
        this.password = password;
    }

    public boolean login(String user, String pass){
        return (this.userName.equals(user) && this.password.equals(pass));
    }

    public void changeuserName(String userName){
        this.userName = userName;
    }

    public void changePassword(String password){
        this.password = password;
    }
}

//Admin Gui ----------------------------------------------------------------------------------------------------------------------------------------------
 class AdminGui extends JFrame {

    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private gui admin;

    public AdminGui(gui admin) {
        this.admin = admin;

        
        setTitle("Admin Login");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== Title Panel =====
        JLabel title = new JLabel("Admin Login", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(title, BorderLayout.NORTH);

        // ===== Center Form Panel ===== 
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        // Username
        c.gridx = 0; c.gridy = 0;
        formPanel.add(new JLabel("Username:"), c);

        c.gridx = 1;
        usernameField = new JTextField(15);
        formPanel.add(usernameField, c);

        // Password
        c.gridx = 0; c.gridy = 1;
        formPanel.add(new JLabel("Password:"), c);

        c.gridx = 1;
        passwordField = new JPasswordField(15);
        formPanel.add(passwordField, c);

        add(formPanel, BorderLayout.CENTER);

        // ===== Login button =====
        JButton loginBtn = new JButton("Login");
        loginBtn.setFont(new Font("Arial", Font.BOLD, 16));
        loginBtn.setFocusPainted(false);
        loginBtn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JPanel btnPanel = new JPanel();
        btnPanel.add(loginBtn);
        add(btnPanel, BorderLayout.SOUTH);

        // ===== Login Action =====
        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (admin.login(usernameField.getText(), new String(passwordField.getPassword()))) {
                    JOptionPane.showMessageDialog(null, "welcome to Helwan University");
                    new AdminMenuGUI().setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Credentials");
                }
            }
        });
    }
}
//Admin Menu Gui----------------------------------------------------------------------------------------------------------------------------------
class AdminMenuGUI extends JFrame {

    public AdminMenuGUI() {
        setTitle("Admin Menu");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== Title =====
        JLabel title = new JLabel("Helwan University", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(title, BorderLayout.NORTH);

        // ===== Buttons Panel =====
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(15, 10, 15, 10);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridx = 0;

        JButton userBtn = styledButton("User Management");
        JButton subjectBtn = styledButton("Subject Management");
        JButton gradeBtn = styledButton("Grade Approval");

        c.gridy = 0; panel.add(userBtn, c);
        c.gridy = 1; panel.add(subjectBtn, c);
        c.gridy = 2; panel.add(gradeBtn, c);

        add(panel, BorderLayout.CENTER);

        // ===== Actions =====
        userBtn.addActionListener(e -> new UserManagementGUI().setVisible(true));
        subjectBtn.addActionListener(e -> new SubjectManagementGUI().setVisible(true));
        gradeBtn.addActionListener(e -> new GradeApprovalGUI().setVisible(true));
    }

    // ===== Reusable method for styling buttons =====
    private JButton styledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 18));
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(250, 50));
        return btn;
    }
}

//  User Class ------------------------------------------------------------------------------------------------------------------------------
// تم تغيير الاسم من User إلى user لتتوافق مع file_manger
class user {
    private String id;
    private String name;
    private String email;
    private String password;

    public user(String id, String name, String email, String password){
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getId(){ return id; }
    public String getName(){ return name; }
    public String getEmail(){ return email; }
    public String getPassword(){ return password; }

    public void setName(String name){ this.name = name; }
    public void setEmail(String email){ this.email = email; }
    public void setPassword(String password){ this.password = password; }

    @Override
    public String toString(){
        return "ID:" + id + " NAME:" + name + " E-MAIL:" + email + " PASSWORD:" + password;
    }
}

// User Management-------------------------------------------------------------------------------------------------------------------- 
class UserManagement {
    private ArrayList<user> users = new ArrayList<>();

    public UserManagement() {
        // تحميل المستخدمين من الملف عند الإنشاء
        this.users = file_manger.loadusers();
    }

    public void addUsers(user user){
        users.add(user);
        file_manger.saveuser(user); // حفظ في الملف
    }

    public boolean deleteUsers(String id){
        boolean removed = users.removeIf(u -> u.getId().equals(id));
        if (removed) {
            file_manger.deleteuser(id); // تحديث الملف
        }
        return removed;
    }

    public boolean updateUsers(String id, String new_name, String new_email, String new_password){
        for(user u : users){
            if(u.getId().equals(id)){
                u.setName(new_name);
                u.setEmail(new_email);
                u.setPassword(new_password);
                file_manger.updateuser(id, new_name, new_email, new_password); // تحديث الملف
                return true;
            }
        }
        return false;
    }

    public user searchUsers(String id){
        for(user u : users){
            if(u.getId().equals(id)){
                return u;
            }
        }
        return null;
    }

    public void listUsers(){
        for(user u : users){
            System.out.println(u);
        }
    }
}
// User Management Gui------------------------------------------------------------------------------------------------------------
class UserManagementGUI extends JFrame {

    private UserManagement userService = new UserManagement();

    public UserManagementGUI() {
        setTitle("User Management");
        setSize(550, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== Title =====
        JLabel title = new JLabel("User Management", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(title, BorderLayout.NORTH);

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(12, 12, 12, 12);
        c.fill = GridBagConstraints.HORIZONTAL;

        JTextField idField = new JTextField(15);
        JTextField nameField = new JTextField(15);
        JTextField emailField = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);

        // Row 1: ID
        c.gridx = 0; c.gridy = 0;
        formPanel.add(new JLabel("ID:"), c);
        c.gridx = 1;
        formPanel.add(idField, c);

        // Row 2: Name
        c.gridx = 0; c.gridy = 1;
        formPanel.add(new JLabel("Name:"), c);
        c.gridx = 1;
        formPanel.add(nameField, c);

        // Row 3: Email
        c.gridx = 0; c.gridy = 2;
        formPanel.add(new JLabel("Email:"), c);
        c.gridx = 1;
        formPanel.add(emailField, c);

        // Row 4: Password
        c.gridx = 0; c.gridy = 3;
        formPanel.add(new JLabel("Password:"), c);
        c.gridx = 1;
        formPanel.add(passwordField, c);

        add(formPanel, BorderLayout.CENTER);

        // ===== Buttons Panel =====
        JPanel btnPanel = new JPanel(new GridBagLayout());
        GridBagConstraints b = new GridBagConstraints();
        b.insets = new Insets(10, 10, 10, 10);
        b.fill = GridBagConstraints.HORIZONTAL;

        JButton addBtn = styledButton("Add User");
        JButton updateBtn = styledButton("Update User");
        JButton deleteBtn = styledButton("Delete User");
        JButton listBtn = styledButton("List Users");

        b.gridx = 0; b.gridy = 0; btnPanel.add(addBtn, b);
        b.gridy = 1; btnPanel.add(updateBtn, b);
        b.gridy = 2; btnPanel.add(deleteBtn, b);
        b.gridy = 3; btnPanel.add(listBtn, b);

        add(btnPanel, BorderLayout.EAST);

        //Actions---------------------------------------------------------------------------------------------------------------------------------

        // Add User
        addBtn.addActionListener(e -> {
            try {
                String id = idField.getText();
                String name = nameField.getText();
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());
                
                userService.addUsers(new user(id, name, email, password));
                JOptionPane.showMessageDialog(this, "User Added Successfully");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        // Update User
        updateBtn.addActionListener(e -> {
            try {
                String id = idField.getText();
                String name = nameField.getText();
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());
                
                if (userService.updateUsers(id, name, email, password)) {
                    JOptionPane.showMessageDialog(this, "User Updated");
                } else {
                    JOptionPane.showMessageDialog(this, "User Not Found");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        // Delete User
        deleteBtn.addActionListener(e -> {
            try {
                String id = idField.getText();
                if (userService.deleteUsers(id)) {
                    JOptionPane.showMessageDialog(this, "User Deleted");
                } else {
                    JOptionPane.showMessageDialog(this, "User Not Found");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        // List Users
        listBtn.addActionListener(e -> userService.listUsers());
    }

    // ===== Styling Buttons =====
    private JButton styledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 16));
        btn.setPreferredSize(new Dimension(150, 40));
        btn.setFocusPainted(false);
        return btn;
    }
}


// Exam Class------------------------------------------------------------------------------------------------------------------------------------
// تم تغيير الاسم من Exam إلى exam لتتوافق مع file_manger
class exam {
    private String examId;
    private String subjectCode;
    private String date;
    private String duration;

    public exam(String examId, String subjectCode, String date, String duration){
        this.examId = examId;
        this.subjectCode = subjectCode;
        this.date = date;
        this.duration = duration;
    }

    public String getExamId(){ return examId; }
    public String getSubjectCode(){ return subjectCode; }
    public String getDate(){ return date; }
    public String getDuration(){ return duration; }

    public void setExamId(String examId){ this.examId = examId; }
    public void setSubjectCode(String subjectCode){ this.subjectCode = subjectCode; }
    public void setDate(String date){ this.date = date; }
    public void setDuration(String duration){ this.duration = duration; }

    @Override
    public String toString() {
        return "exam{" +
                "examId=" + examId +
                ", subjectCode=" + subjectCode +
                ", date=" + date +
                ", duration=" + duration +
                '}';
    }
}

// ======= Grade Approval =======
class GradeApproval {
    public void reviewGrades(exam exam){
        System.out.println("Reviewing grades: " + exam.getExamId());
    }

    public void approvedGrades(exam exam){
        System.out.println("Grades Approved for exam: " + exam.getExamId());
        file_manger.saveexam(exam); // حفظ في الملف
    }

    public void publishGrades(exam exam){
        System.out.println("Results published successfully for exam: " + exam.getExamId());
    }
}

// ======= Student Class =======
// تم تغيير الاسم من Student إلى student لتتوافق مع file_manger
class student {
    private String id;
    private String name;
    private String email;
    private String password;
    private String level;

    public student(String id, String name, String email, String password, String level){
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.level = level;
    }

    public String getId(){ return id; }
    public String getName(){ return name; }
    public String getEmail(){ return email; }
    public String getPassword(){ return password; }
    public String getLevel(){ return level; }

    @Override
    public String toString(){
        return "student{id=" + id + ", name='" + name + "', email='" + email + "', level='" + level + "'}";
    }
}

// ======= Lecturer Class =======
// تم تغيير الاسم من Lecturer إلى lecture لتتوافق مع file_manger
class lecture {
    private String id;
    private String name;
    private String email;
    private String password;
    private String department;

    public lecture(String id, String name, String email, String password, String department){
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.department = department;
    }

    public String getId(){ return id; }
    public String getName(){ return name; }
    public String getEmail(){ return email; }
    public String getPassword(){ return password; }
    public String getDepartment(){ return department; }

    public void setName(String name){ this.name = name; }
    public void setEmail(String email){ this.email = email; }
    public void setPassword(String password){ this.password = password; }
    public void setDepartment(String department){ this.department = department; }

    @Override
    public String toString(){
        return "lecture{id=" + id + ", name=" + name + ", email=" + email + ", department=" + department + "}";
    }
}

// ======= Subject Class =======
// تم تغيير الاسم من Subject إلى subject لتتوافق مع file_manger
class subject {
    private String code;
    private String name;
    private String level;
    private String creditHours;
    
    public subject(String code, String name, String level, String creditHours){
        this.code = code;
        this.name = name;
        this.level = level;
        this.creditHours = creditHours;
    }

    public String getCode(){ return code; }
    public String getName(){ return name; }
    public String getLevel(){ return level; }
    public String getCreditHours(){ return creditHours; }

    @Override
    public String toString(){
        return "subject{code=" + code + ", name='" + name + "', level=" + level + "}";
    }
}

// ======= Subject Management =======
class SubjectManagement {
    private ArrayList<subject> subjects = new ArrayList<>();

    public SubjectManagement() {
        // تحميل المواد من الملف عند الإنشاء
        this.subjects = file_manger.loadsubjects();
    }

    public ArrayList<subject> getSubjects() {
        return subjects;
    }

    public void addSubject(subject sub){
        subjects.add(sub);
        file_manger.savesubject(sub); // حفظ في الملف
    }

    public void assignSubjectToStudent(String subjectCode, student s){
        for(subject sub : subjects){
            if(sub.getCode().equals(subjectCode)){
                System.out.println("Assigned student " + s.getName() + " to subject " + sub.getName());
                file_manger.savestudent(s); // حفظ الطالب في الملف
            }
        }
    }

    public void assignSubjectToLecturer(String subjectCode, lecture l){
        for(subject sub : subjects){
            if(sub.getCode().equals(subjectCode)){
                System.out.println("Assigned lecturer " + l.getName() + " to subject " + sub.getName());
                file_manger.savelec(l); // حفظ المحاضر في الملف
            }
        }
    }

    public void listSubjects(){
        for(subject sub : subjects){
            System.out.println(sub);
        }
    }
}

// Subject Management Gui------------------------------------------------------------------------------------------------------------------------------------
class SubjectManagementGUI extends JFrame {

    private SubjectManagement subjectService = new SubjectManagement();

    public SubjectManagementGUI() {
        setTitle("Subject Management");
        setSize(600, 480);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== Title =====
        JLabel title = new JLabel("Subject Management", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(title, BorderLayout.NORTH);

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(12, 12, 12, 12);
        c.fill = GridBagConstraints.HORIZONTAL;

        JTextField subjectCodeField = new JTextField(15);
        JTextField subjectNameField = new JTextField(15);
        JTextField levelField = new JTextField(15);
        JTextField creditHoursField = new JTextField(15);

        // Subject Code
        c.gridx = 0; c.gridy = 0;
        formPanel.add(new JLabel("Subject Code:"), c);
        c.gridx = 1;
        formPanel.add(subjectCodeField, c);

        // Subject Name
        c.gridx = 0; c.gridy = 1;
        formPanel.add(new JLabel("Subject Name:"), c);
        c.gridx = 1;
        formPanel.add(subjectNameField, c);

        // Level
        c.gridx = 0; c.gridy = 2;
        formPanel.add(new JLabel("Level:"), c);
        c.gridx = 1;
        formPanel.add(levelField, c);

        // Credit Hours
        c.gridx = 0; c.gridy = 3;
        formPanel.add(new JLabel("Credit Hours:"), c);
        c.gridx = 1;
        formPanel.add(creditHoursField, c);

        add(formPanel, BorderLayout.CENTER);

        // ===== Buttons Panel =====
        JPanel btnPanel = new JPanel(new GridBagLayout());
        GridBagConstraints b = new GridBagConstraints();
        b.insets = new Insets(10, 10, 10, 10);
        b.fill = GridBagConstraints.HORIZONTAL;

        JButton addBtn = styledButton("Add Subject");
        JButton assignStudentBtn = styledButton("Assign Student");
        JButton assignLecturerBtn = styledButton("Assign Lecturer");
        JButton listBtn = styledButton("List Subjects");

        b.gridx = 0; b.gridy = 0; btnPanel.add(addBtn, b);
        b.gridy = 1; btnPanel.add(assignStudentBtn, b);
        b.gridy = 2; btnPanel.add(assignLecturerBtn, b);
        b.gridy = 3; btnPanel.add(listBtn, b);

        add(btnPanel, BorderLayout.EAST);

        // ===== Actions =====

        // Add Subject
        addBtn.addActionListener(e -> {
            try {
                String code = subjectCodeField.getText();
                String name = subjectNameField.getText();
                String level = levelField.getText();
                String creditHours = creditHoursField.getText();
                
                subjectService.addSubject(new subject(code, name, level, creditHours));
                JOptionPane.showMessageDialog(this, "Subject Added");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        // Assign Student
        assignStudentBtn.addActionListener(e -> {
            try {
                String subjectCode = subjectCodeField.getText();
                String studentId = JOptionPane.showInputDialog(this, "Enter Student ID:");
                
                if (studentId != null && !studentId.trim().isEmpty()) {
                    student s = new student(studentId, "Student " + studentId,
                            "student" + studentId + "@mail.com", "password", "1");
                    
                    subjectService.assignSubjectToStudent(subjectCode, s);
                    JOptionPane.showMessageDialog(this, "Student Assigned");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        // Assign Lecturer
        assignLecturerBtn.addActionListener(e -> {
            try {
                String subjectCode = subjectCodeField.getText();
                String lecturerId = JOptionPane.showInputDialog(this, "Enter Lecturer ID:");
                
                if (lecturerId != null && !lecturerId.trim().isEmpty()) {
                    lecture l = new lecture(lecturerId, "Lecturer " + lecturerId,
                            "lecturer" + lecturerId + "@mail.com", "password", "CS");
                    
                    subjectService.assignSubjectToLecturer(subjectCode, l);
                    JOptionPane.showMessageDialog(this, "Lecturer Assigned");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        // List Subjects
        listBtn.addActionListener(e -> subjectService.listSubjects());
    }

    // ===== Reusable Button Style =====
    private JButton styledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 16));
        btn.setPreferredSize(new Dimension(170, 40));
        btn.setFocusPainted(false);
        return btn;
    }
}

// Grade Aooroval Gui--------------------------------------------------------------------------------------------------------------------------------------
class GradeApprovalGUI extends JFrame {

    private GradeApproval gradeService = new GradeApproval();

    public GradeApprovalGUI() {
        setTitle("Grade Approval System");
        setSize(550, 420);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== Title =====
        JLabel title = new JLabel("Grade Approval", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(title, BorderLayout.NORTH);

        // ===== Form Panel =====
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(15, 15, 15, 15);
        c.fill = GridBagConstraints.HORIZONTAL;

        JTextField examIdField = new JTextField(15);
        JTextField subjectCodeField = new JTextField(15);
        JTextField dateField = new JTextField(15);
        JTextField durationField = new JTextField(15);

        // Exam ID row
        c.gridx = 0; c.gridy = 0;
        formPanel.add(new JLabel("Exam ID:"), c);
        c.gridx = 1;
        formPanel.add(examIdField, c);

        // Subject Code row
        c.gridx = 0; c.gridy = 1;
        formPanel.add(new JLabel("Subject Code:"), c);
        c.gridx = 1;
        formPanel.add(subjectCodeField, c);

        // Date row
        c.gridx = 0; c.gridy = 2;
        formPanel.add(new JLabel("Date:"), c);
        c.gridx = 1;
        formPanel.add(dateField, c);

        // Duration row
        c.gridx = 0; c.gridy = 3;
        formPanel.add(new JLabel("Duration:"), c);
        c.gridx = 1;
        formPanel.add(durationField, c);

        add(formPanel, BorderLayout.CENTER);

        // ===== Buttons Panel =====
        JPanel btnPanel = new JPanel(new GridBagLayout());
        GridBagConstraints b = new GridBagConstraints();
        b.insets = new Insets(10, 10, 10, 10);
        b.fill = GridBagConstraints.HORIZONTAL;

        JButton reviewBtn = styledButton("Review Grades");
        JButton approveBtn = styledButton("Approve Exam");
        JButton publishBtn = styledButton("Publish Results");

        b.gridx = 0; b.gridy = 0;
        btnPanel.add(reviewBtn, b);

        b.gridy = 1;
        btnPanel.add(approveBtn, b);

        b.gridy = 2;
        btnPanel.add(publishBtn, b);

        add(btnPanel, BorderLayout.EAST);

        // ===== Actions =====

        // Review Grades
        reviewBtn.addActionListener(e -> {
            try {
                String examId = examIdField.getText();
                exam exam = new exam(examId, subjectCodeField.getText(), 
                                    dateField.getText(), durationField.getText());
                gradeService.reviewGrades(exam);
                JOptionPane.showMessageDialog(this, "Grades Reviewed");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        // Approve Grades
        approveBtn.addActionListener(e -> {
            try {
                String examId = examIdField.getText();
                exam exam = new exam(examId, subjectCodeField.getText(), 
                                    dateField.getText(), durationField.getText());
                gradeService.approvedGrades(exam);
                JOptionPane.showMessageDialog(this, "Exam Approved and Saved");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });

        // Publish Grades
        publishBtn.addActionListener(e -> {
            try {
                String examId = examIdField.getText();
                exam exam = new exam(examId, subjectCodeField.getText(), 
                                    dateField.getText(), durationField.getText());
                gradeService.publishGrades(exam);
                JOptionPane.showMessageDialog(this, "Results Published");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid Input!");
            }
        });
    }

    // ===== Button Styling =====
    private JButton styledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Arial", Font.BOLD, 16));
        btn.setPreferredSize(new Dimension(170, 40));
        btn.setFocusPainted(false);
        return btn;
    }
}

class Main {
    public static void main(String[] args) {
        gui admin = new gui("fathy", "123");
        SwingUtilities.invokeLater(() -> {
            AdminGui gui = new AdminGui(admin);
            gui.setVisible(true);
        });
    }
}